import { SubTitle } from '../../styles/CommonStyle';

const MainText = ({ text }) => {
  return <SubTitle color="purple">{text}</SubTitle>;
};

export default MainText;
